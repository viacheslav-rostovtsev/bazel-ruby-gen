module Rainbow
  VERSION = "3.0.0".freeze
end
