module RDoc

  ##
  # RDoc version you are using

  VERSION = '6.1.2'

end
