module DidYouMean
  VERSION = "1.3.0"
end
